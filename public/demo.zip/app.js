
App({
  onLaunch() {
    // Exhibit the startup logic
    const logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    // Login logic
    wx.login({
      success: res => {
        // Send res.code to backend
        console.log('Login Code:', res.code);
      }
    })
  },
  globalData: {
    userInfo: null
  }
})
